#!/usr/bin/env python3
"""Repara a branch de hardening do Xhakinha de forma conservadora.

- Corrige a indentação quebrada em pipeline.py e web/app.py.
- Adiciona a aba Rostos ao painel, conectada às rotas biométricas.
- Restringe perfis faciais a fontes autorizadas por ID e falha fechado.
- Corrige a confirmação de revogação e migra o schema para v6.
- Adiciona testes para escopo biométrico, validade e armazenamento cifrado.
- Faz backup de todos os arquivos antes de editar.
- Compila Python/JavaScript e roda pytest.
- Só cria commit/push se --push for passado e todos os testes passarem.

Execute na raiz local do repositório Xhakinha:
  python repair_xhakinha.py
  python repair_xhakinha.py --push  # apenas depois da suíte verde
"""
from __future__ import annotations

import argparse
import datetime as dt
import shutil
import subprocess
import sys
from pathlib import Path

BRANCH_DEFAULT = "feature/production-hardening-20261127"
FILES = {
    "db": Path("xhakinha-clips-ai/xhakinha/db.py"),
    "faces": Path("xhakinha-clips-ai/xhakinha/faces.py"),
    "faces_web": Path("xhakinha-clips-ai/xhakinha/faces_web.py"),
    "pipeline": Path("xhakinha-clips-ai/xhakinha/pipeline.py"),
    "app": Path("xhakinha-clips-ai/xhakinha/web/app.py"),
    "frontend": Path("xhakinha-clips-ai/xhakinha/web/static/app.js"),
    "turso_tests": Path("xhakinha-clips-ai/tests/test_turso.py"),
    "face_tests": Path("xhakinha-clips-ai/tests/test_face_profiles_scoped.py"),
}


def run(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=check)


def fail(message: str, code: int = 2) -> None:
    print(f"ERRO: {message}", file=sys.stderr)
    raise SystemExit(code)


def method_bounds(lines: list[str], method: str) -> tuple[int, int]:
    marker = f"    def {method}("
    starts = [i for i, line in enumerate(lines) if line.startswith(marker)]
    if len(starts) != 1:
        fail(f"esperava exatamente um método {method}; encontrados {len(starts)}")
    start = starts[0]
    end = len(lines)
    for i in range(start + 1, len(lines)):
        if lines[i].startswith("    def ") or lines[i].startswith("    @"):
            end = i
            break
    return start, end


def set_method_line(lines: list[str], method: str, prefix: str, occurrence: int, indent: int) -> None:
    start, end = method_bounds(lines, method)
    matches = [i for i in range(start + 1, end) if lines[i].lstrip().startswith(prefix)]
    if len(matches) < occurrence:
        fail(f"{method}: trecho não encontrado ({prefix!r}); encontrados {len(matches)}")
    idx = matches[occurrence - 1]
    content = lines[idx].lstrip(" \t")
    lines[idx] = (" " * indent) + content


def repair_pipeline(source: str) -> str:
    lines = source.splitlines()
    # Publicação e tratamento de erros.
    set_method_line(lines, "h_publish", "self._again(pid, res.wait_s)", 1, 20)
    set_method_line(lines, "h_publish", 'scheduler.refresh_clip_status(self.db, clip["id"])', 1, 20)
    set_method_line(lines, "h_publish", 'scheduler.refresh_clip_status(self.db, clip["id"])', 2, 20)
    set_method_line(lines, "h_publish", "perm = isinstance(e, PermanentError)", 1, 12)
    set_method_line(lines, "h_publish", 'self.db.x("UPDATE publications SET status=?, error=?, needs_admin=?, updated=? WHERE id=?",', 1, 12)
    set_method_line(lines, "h_publish", 'self.db.attempt("publication", pid, "publish", False, str(e))', 1, 12)
    set_method_line(lines, "h_publish", 'scheduler.refresh_clip_status(self.db, clip["id"])', 3, 12)

    # Reagendamento idempotente.
    set_method_line(lines, "_again", "self.db.x(\"UPDATE jobs SET status='done'", 1, 8)
    set_method_line(lines, "_again", 'self.q.enqueue("publish", {"pub_id": pid}, run_at=', 1, 8)

    # Coleta de métricas.
    set_method_line(lines, "h_metrics", 'pub = self.db.one("SELECT * FROM publications WHERE id=?", (job["payload"]["pub_id"],))', 1, 8)
    set_method_line(lines, "h_metrics", 'm = self.pubs[pub["platform"]].fetch_metrics(pub)', 1, 8)
    set_method_line(lines, "h_metrics", 'self.db.attempt("publication", pub["id"], "metrics"', 1, 12)
    set_method_line(lines, "h_metrics", "ret = None", 1, 8)
    set_method_line(lines, "h_metrics", 'clip = self.db.one("SELECT duration FROM clips WHERE id=?", (pub["clip_id"],))', 1, 8)
    set_method_line(lines, "h_metrics", 'ret = min(1.0, (m["_avg_ms"] / 1000.0)', 1, 12)
    set_method_line(lines, "h_metrics", 'self.db.x("INSERT INTO metrics(publication_id,ts,views,likes,comments,shares,retention,raw)', 1, 8)

    # Métodos de manutenção.
    for method in ("h_cleanup", "h_backup"):
        start, end = method_bounds(lines, method)
        for i in range(start + 1, end):
            stripped = lines[i].lstrip(" \t")
            if stripped and not stripped.startswith("#"):
                current = len(lines[i]) - len(stripped)
                if current == 1:
                    lines[i] = "        " + stripped

    # Retentativa administrativa.
    set_method_line(lines, "retry_publication", 'pub = self.db.one("SELECT * FROM publications WHERE id=?", (pid,))', 1, 8)
    set_method_line(lines, "retry_publication", 'st = json.loads(pub["state"] or "{}")', 1, 8)
    set_method_line(lines, "retry_publication", 'st["stage"] = "init"', 1, 12)
    set_method_line(lines, "retry_publication", 'self.db.x("UPDATE publications SET status=\'scheduled\'', 1, 12)
    set_method_line(lines, "retry_publication", 'self.db.x("UPDATE jobs SET status=\'done\'', 1, 12)
    set_method_line(lines, "retry_publication", 'self.q.enqueue("publish", {"pub_id": pid}', 1, 12)
    set_method_line(lines, "retry_publication", 'scheduler.refresh_clip_status(self.db, pub["clip_id"])', 1, 12)
    return "\n".join(lines) + ("\n" if source.endswith("\n") else "")


def repair_app(source: str) -> str:
    lines = source.splitlines()
    replacements = {"v = cast(v)": 8, 'v = str(v or "").strip()': 4}
    counts = {key: 0 for key in replacements}
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped in replacements:
            lines[i] = " " * replacements[stripped] + stripped
            counts[stripped] += 1
    for key, count in counts.items():
        if count != 1:
            fail(f"web/app.py: esperava 1 ocorrência de {key!r}, encontrei {count}")
    return "\n".join(lines) + ("\n" if source.endswith("\n") else "")


def repair_db(source: str) -> str:
    old_col = "  reference_count INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, updated REAL NOT NULL);"
    new_col = "  reference_count INTEGER NOT NULL DEFAULT 0, consent_sources TEXT NOT NULL DEFAULT '[]', created REAL NOT NULL, updated REAL NOT NULL);"
    if source.count(old_col) != 1:
        fail("db.py: definição da tabela face_profiles mudou; revisão manual necessária")
    source = source.replace(old_col, new_col)

    old_migration = '            ("face_profiles", "consent_evidence", "TEXT NOT NULL DEFAULT \'\'"),'
    new_migration = old_migration + '\n            ("face_profiles", "consent_sources", "TEXT NOT NULL DEFAULT \'[]\'"),'
    if source.count(old_migration) != 1:
        fail("db.py: bloco _migrate mudou; revisão manual necessária")
    source = source.replace(old_migration, new_migration)

    old_version = "SCHEMA_VERSION = 5          # 5 = referência documental do consentimento facial."
    new_version = "SCHEMA_VERSION = 6          # 6 = escopo biométrico limitado a fontes autorizadas."
    if source.count(old_version) != 1:
        fail("db.py: SCHEMA_VERSION mudou; revisão manual necessária")
    return source.replace(old_version, new_version)


def repair_faces(source: str) -> str:
    if "import json\n" not in source:
        anchor = "import hashlib\n"
        if source.count(anchor) != 1:
            fail("faces.py: bloco de imports mudou; revisão manual necessária")
        source = source.replace(anchor, "import hashlib\nimport json\n")
    start = source.find("def active_profiles(")
    end = source.find("\ndef match_interval(", start)
    if start < 0 or end < 0:
        fail("faces.py: active_profiles/match_interval não encontrados")
    replacement = '''def active_profiles(
    db, now: float | None = None, *, source_id: int | None = None
) -> list[dict]:
    """Carrega perfis ativos somente para a fonte explicitamente autorizada.

    Sem source_id, ou sem consent_sources válido, falha fechado e não reconhece.
    """
    if source_id is None:
        return []
    try:
        source_id = int(source_id)
    except (TypeError, ValueError):
        return []
    source = db.one("SELECT authorized FROM sources WHERE id=?", (source_id,))
    if not source or not bool(source.get("authorized")):
        return []
    now = float(now if now is not None else time.time())
    rows = db.q(
        "SELECT id,name,threshold,consent_expires,reference_count,consent_sources "
        "FROM face_profiles "
        "WHERE revoked_at IS NULL AND (consent_expires IS NULL OR consent_expires>?) "
        "ORDER BY id",
        (now,),
    )
    profiles = []
    for row in rows:
        try:
            allowed = json.loads(row.get("consent_sources") or "[]")
            allowed_ids = {int(item) for item in allowed}
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        if source_id not in allowed_ids:
            continue
        secret = db.get_secret(f"face_profile:{row['id']}")
        vectors = secret.get("embeddings") if isinstance(secret, dict) else None
        if not isinstance(vectors, list):
            continue
        clean = []
        for item in vectors:
            try:
                vector = np.asarray(item, dtype=np.float32).reshape(-1)
                norm = float(np.linalg.norm(vector))
                if (
                    vector.size == EMBEDDING_SIZE
                    and np.isfinite(vector).all()
                    and norm > 1e-8
                ):
                    clean.append((vector / norm).astype(np.float32))
            except Exception:
                continue
        if clean:
            profiles.append(
                {
                    "id": int(row["id"]),
                    "name": str(row["name"]),
                    "threshold": float(row["threshold"] or DEFAULT_THRESHOLD),
                    "embeddings": clean,
                }
            )
    return profiles
'''
    return source[:start] + replacement + source[end + 1:]


def repair_faces_web(source: str) -> str:
    if "import json\n" not in source:
        anchor = "import time\n"
        if source.count(anchor) != 1:
            fail("faces_web.py: bloco de imports mudou; revisão manual necessária")
        source = source.replace(anchor, "import json\nimport time\n")

    helper_anchor = "MAX_REFERENCE_BYTES = 5 * 1024 * 1024\n"
    helper_code = '''MAX_REFERENCE_BYTES = 5 * 1024 * 1024


def remove_profile_face_matches(db, profile_id: int) -> int:
    """Remove só as marcações do perfil revogado, sem tocar nos vídeos."""
    target = str(int(profile_id))
    changed = 0
    rows = db.q(
        "SELECT id,face_matches FROM clips WHERE face_matches IS NOT NULL"
    )
    for row in rows:
        try:
            matches = json.loads(row.get("face_matches") or "[]")
        except (TypeError, ValueError):
            matches = None
        if isinstance(matches, list):
            cleaned = [
                item for item in matches
                if not (
                    isinstance(item, dict)
                    and str(item.get("profile_id")) == target
                )
            ]
        else:
            # JSON inválido/formato inesperado: falha fechado, removendo o campo.
            cleaned = []
        if not isinstance(matches, list) or cleaned != matches:
            db.x(
                "UPDATE clips SET face_matches=? WHERE id=?",
                (json.dumps(cleaned, separators=(",", ":")), row["id"]),
            )
            changed += 1
    return changed
'''
    if source.count(helper_anchor) != 1:
        fail("faces_web.py: ponto de inserção do helper de revogação mudou")
    if "def remove_profile_face_matches(" not in source:
        source = source.replace(helper_anchor, helper_code, 1)

    old_select = '''                "SELECT id,name,consent_scope,consent_evidence,consent_by,"
                "consent_recorded,consent_expires,revoked_at,reference_count "'''
    new_select = '''                "SELECT id,name,consent_scope,consent_evidence,consent_by,"
                "consent_recorded,consent_expires,revoked_at,reference_count,consent_sources "'''
    if source.count(old_select) != 1:
        fail("faces_web.py: consulta de perfis mudou; revisão manual necessária")
    source = source.replace(old_select, new_select)

    old_active = '''            for row in rows:
                row["active"] = ('''
    new_active = '''            authorized_source_ids = {
                int(source["id"])
                for source in db.q("SELECT id FROM sources WHERE authorized=1")
            }
            for row in rows:
                try:
                    row["consent_sources"] = [
                        int(source_id)
                        for source_id in json.loads(row.get("consent_sources") or "[]")
                    ]
                except (TypeError, ValueError, json.JSONDecodeError):
                    row["consent_sources"] = []
                row["active"] = ('''
    if source.count(old_active) != 1:
        fail("faces_web.py: bloco de status ativo mudou; revisão manual necessária")
    source = source.replace(old_active, new_active)
    old_active_end = '''                        or float(row["consent_expires"]) > now
                    )
                )'''
    new_active_end = '''                        or float(row["consent_expires"]) > now
                    )
                    and bool(set(row["consent_sources"]) & authorized_source_ids)
                )'''
    if source.count(old_active_end) != 1:
        fail("faces_web.py: condição active mudou; revisão manual necessária")
    source = source.replace(old_active_end, new_active_end)

    old_fields = '''        expiry_text = str(form.get("expires", "")).strip()
        accepted = str(form.get("consent_confirmed", "")).lower() in ('''
    new_fields = '''        expiry_text = str(form.get("expires", "")).strip()
        source_text = str(form.get("source_ids", "")).strip()
        accepted = str(form.get("consent_confirmed", "")).lower() in ('''
    if source.count(old_fields) != 1:
        fail("faces_web.py: campos do formulário mudaram; revisão manual necessária")
    source = source.replace(old_fields, new_fields)

    old_validation = '''        if not accepted:
            raise FaceRecognitionError(
                "confirme que existe autorização expressa para uso biométrico"
            )

        expiry = None'''
    new_validation = '''        if not accepted:
            raise FaceRecognitionError(
                "confirme que existe autorização expressa para uso biométrico"
            )
        try:
            raw_source_ids = json.loads(source_text)
            if not isinstance(raw_source_ids, list) or not raw_source_ids:
                raise ValueError
            def _source_id(value):
                if isinstance(value, bool):
                    raise ValueError
                if isinstance(value, int):
                    result = value
                elif isinstance(value, str) and value.isdecimal():
                    result = int(value)
                else:
                    raise ValueError
                if result <= 0:
                    raise ValueError
                return result

            source_ids = sorted({_source_id(value) for value in raw_source_ids})
            if len(source_ids) != len(raw_source_ids) or any(value <= 0 for value in source_ids):
                raise ValueError
            if len(source_ids) > 100:
                raise ValueError
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise FaceRecognitionError(
                "selecione ao menos uma fonte autorizada (IDs válidos)"
            ) from exc
        placeholders = ",".join("?" for _ in source_ids)
        found_sources = db.q(
            f"SELECT id FROM sources WHERE authorized=1 AND id IN ({placeholders})",
            tuple(source_ids),
        )
        if {int(row["id"]) for row in found_sources} != set(source_ids):
            raise FaceRecognitionError("uma ou mais fontes selecionadas não existem")

        expiry = None'''
    if source.count(old_validation) != 1:
        fail("faces_web.py: validação de consentimento mudou; revisão manual necessária")
    source = source.replace(old_validation, new_validation)

    old_insert = '''            "name,consent_version,consent_scope,consent_evidence,consent_recorded,"
            "consent_by,consent_expires,revoked_at,threshold,reference_count,created,updated"
            ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",'''
    new_insert = '''            "name,consent_version,consent_scope,consent_evidence,consent_sources,consent_recorded,"
            "consent_by,consent_expires,revoked_at,threshold,reference_count,created,updated"
            ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",'''
    if source.count(old_insert) != 1:
        fail("faces_web.py: INSERT de face_profiles mudou; revisão manual necessária")
    source = source.replace(old_insert, new_insert)
    old_values = '''                scope,
                evidence,
                now,
                creator,'''
    new_values = '''                scope,
                evidence,
                json.dumps(source_ids),
                now,
                creator,'''
    if source.count(old_values) != 1:
        fail("faces_web.py: valores do INSERT de face_profiles mudaram; revisão manual necessária")
    source = source.replace(old_values, new_values)

    old_revoke = '''    async def revoke(request: Request):
        profile_id = int(request.path_params["pid"])
        now = time.time()
        changed = db.x(
            "UPDATE face_profiles SET revoked_at=?,updated=? "
            "WHERE id=? AND revoked_at IS NULL",
            (now, now, profile_id),
        )
        db.del_secret(f"face_profile:{profile_id}")
        db.event(
            "info",
            "faces",
            f"Consentimento facial revogado (perfil {profile_id})",
            profile_id=profile_id,
        )
        return JSONResponse({"ok": True, "revoked": bool(changed)})'''
    new_revoke = '''    async def revoke(request: Request):
        profile_id = int(request.path_params["pid"])
        now = time.time()
        # RETURNING torna a transição atômica: apenas a primeira revogação conta.
        changed = db.one(
            "UPDATE face_profiles SET revoked_at=?,updated=? "
            "WHERE id=? AND revoked_at IS NULL RETURNING id",
            (now, now, profile_id),
        ) is not None
        # Sempre remove o material biométrico, inclusive em uma revogação repetida.
        db.del_secret(f"face_profile:{profile_id}")
        # Só remove as correspondências deste perfil; outros perfis e vídeos permanecem.
        cleared_matches = remove_profile_face_matches(db, profile_id)
        if changed:
            db.event(
                "info",
                "faces",
                f"Consentimento facial revogado (perfil {profile_id}); "
                f"marcações removidas de {cleared_matches} clipes",
                profile_id=profile_id,
                cleared_clips=cleared_matches,
            )
        return JSONResponse({"ok": True, "revoked": changed})'''
    if source.count(old_revoke) != 1:
        fail("faces_web.py: função de revogação mudou; revisão manual necessária")
    return source.replace(old_revoke, new_revoke)


def repair_pipeline_faces(source: str) -> str:
    old = "face_profiles = active_profiles(self.db)"
    new = "face_profiles = active_profiles(self.db, source_id=c[\"source_id\"])"
    if source.count(old) != 1:
        fail("pipeline.py: chamada a active_profiles mudou; revisão manual necessária")
    return source.replace(old, new)


def repair_turso_tests(source: str) -> str:
    old = 'assert b.get("x") == 1 and b.get("schema_version") == 5'
    new = 'assert b.get("x") == 1 and b.get("schema_version") == 6'
    if source.count(old) != 1:
        fail("test_turso.py: expectativa de schema_version v5 não encontrada exatamente uma vez")
    return source.replace(old, new)


FACE_TESTS = '''"""Testes do escopo de consentimento biométrico por fonte."""
from __future__ import annotations

import json
import time

import pytest

from xhakinha.faces import FaceRecognitionError, active_profiles, append_reference


def make_profile(db, name: str, source_ids: list[int], expires: float | None = None) -> int:
    now = time.time()
    return db.x(
        "INSERT INTO face_profiles("
        "name,consent_version,consent_scope,consent_evidence,consent_sources,"
        "consent_recorded,consent_by,consent_expires,revoked_at,threshold,"
        "reference_count,created,updated"
        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            name, "test-v1", "teste com fontes delimitadas", "autorização de teste",
            json.dumps(source_ids), now, "pytest", expires, None, 0.50, 0, now, now,
        ),
    )


def embedding():
    return [1.0] + [0.0] * 127


def make_source(db, name: str, authorized: int = 1) -> int:
    return db.x(
        "INSERT INTO sources(platform,name,ref,enabled,authorized,interval_s,created) "
        "VALUES(?,?,?,?,?,?,?)",
        ("youtube", name, f"https://example.invalid/{name}", 1, authorized, 300, time.time()),
    )


def test_face_profile_only_matches_explicitly_authorized_source(engine):
    db = engine.db
    source_a = make_source(db, "fonte-a")
    source_b = make_source(db, "fonte-b")
    first = make_profile(db, "Pessoa A", [source_a])
    second = make_profile(db, "Pessoa B", [source_b])
    append_reference(db, first, embedding())
    append_reference(db, second, embedding())

    assert [p["id"] for p in active_profiles(db, source_id=source_a)] == [first]
    assert [p["id"] for p in active_profiles(db, source_id=source_b)] == [second]
    assert active_profiles(db, source_id=303) == []
    assert active_profiles(db) == []  # sem origem explícita, falha fechado


def test_face_profile_is_not_used_for_an_unauthorized_source(engine):
    db = engine.db
    source_id = make_source(db, "fonte-sem-autorizacao", authorized=0)
    profile = make_profile(db, "Pessoa A", [source_id])
    append_reference(db, profile, embedding())
    assert active_profiles(db, source_id=source_id) == []


def test_expired_and_revoked_profiles_are_not_active(engine):
    db = engine.db
    source_id = make_source(db, "fonte-expirada")
    expired = make_profile(db, "Expirada", [source_id], expires=time.time() - 10)
    revoked = make_profile(db, "Revogada", [source_id])
    append_reference(db, expired, embedding())
    append_reference(db, revoked, embedding())
    db.x("UPDATE face_profiles SET revoked_at=? WHERE id=?", (time.time(), revoked))
    db.del_secret(f"face_profile:{revoked}")
    assert active_profiles(db, source_id=source_id) == []


def test_face_reference_is_normalized_encrypted_and_capped(engine):
    db = engine.db
    source_id = make_source(db, "fonte-c")
    profile = make_profile(db, "Pessoa C", [source_id])
    for _ in range(20):
        assert append_reference(db, profile, embedding()) >= 1
    with pytest.raises(FaceRecognitionError, match="limite de 20"):
        append_reference(db, profile, embedding())
    rows = active_profiles(db, source_id=source_id)
    assert len(rows) == 1 and len(rows[0]["embeddings"]) == 20
    assert abs(float(rows[0]["embeddings"][0][0]) - 1.0) < 1e-6
    stored = db.one("SELECT value FROM secrets WHERE name=?", (f"face_profile:{profile}",))
    assert stored and '"embeddings"' not in stored["value"]


def test_revocation_cleanup_handles_compact_json_and_last_item():
    from xhakinha.faces_web import remove_profile_face_matches

    class MemoryDB:
        def __init__(self):
            self.rows = [
                {"id": 1, "face_matches": '[{"profile_id":8},{"profile_id":9}]'},
                {"id": 2, "face_matches": '[{"profile_id":9},{"profile_id":8}]'},
                {"id": 3, "face_matches": 'not-json'},
                {"id": 4, "face_matches": '[]'},
            ]

        def q(self, query):
            assert "SELECT id,face_matches FROM clips" in query
            return self.rows

        def x(self, query, params):
            assert "UPDATE clips SET face_matches=? WHERE id=?" in query
            value, row_id = params
            next(row for row in self.rows if row["id"] == row_id)["face_matches"] = value

    db = MemoryDB()
    assert remove_profile_face_matches(db, 8) == 3
    assert json.loads(db.rows[0]["face_matches"]) == [{"profile_id": 9}]
    assert json.loads(db.rows[1]["face_matches"]) == [{"profile_id": 9}]
    assert json.loads(db.rows[2]["face_matches"]) == []
    assert db.rows[3]["face_matches"] == '[]'
'''


API_FORM_HELPER = r'''async function apiForm(path, form) {
  const r = await fetch(path, { method: 'POST', credentials: 'same-origin', headers: H, body: form });
  let j = null; try { j = await r.json(); } catch (e) {}
  if (r.status === 401) { me = null; render(); throw new Error('sessão expirada'); }
  if (!r.ok) throw new Error((j && j.error) || ('HTTP ' + r.status));
  return j;
}
'''

FACES_UI = r'''/* ---------------- Rostos autorizados ---------------- */
async function vRostos() {
  const [rows, allSources] = await Promise.all([api('/api/faces'), api('/api/sources')]);
  const sources = allSources.filter(source => !!source.authorized);
  const sourceNames = new Map(sources.map(source => [Number(source.id), `${source.name} (${source.platform})`]));
  const name = h('input', { placeholder: 'Nome da pessoa autorizada', maxlength: 80 });
  const scope = h('textarea', { rows: 3, placeholder: 'Finalidade e contexto do uso autorizado' });
  const evidence = h('input', { placeholder: 'Referência da autorização (ex.: contrato ou mensagem)', maxlength: 500 });
  const expires = h('input', { type: 'date' });
  const photo = h('input', { type: 'file', accept: 'image/*' });
  const consent = h('input', { type: 'checkbox' });
  const sourceInputs = sources.map(source => {
    const cb = h('input', { type: 'checkbox', value: String(source.id) });
    return h('label', { class: 'ck' }, cb, `${source.name} (${source.platform})`);
  });
  const create = h('button', { class: 'b', onclick: () => act(async () => {
    if (!photo.files || !photo.files[0]) throw new Error('Selecione uma foto clara com apenas um rosto.');
    const allowedSources = sourceInputs
      .filter(item => item.querySelector('input').checked)
      .map(item => Number(item.querySelector('input').value));
    if (!allowedSources.length) throw new Error('Selecione ao menos uma fonte para a qual existe autorização expressa.');
    const form = new FormData();
    form.set('name', name.value); form.set('scope', scope.value); form.set('evidence', evidence.value);
    form.set('expires', expires.value); form.set('consent_confirmed', consent.checked ? 'true' : 'false');
    form.set('source_ids', JSON.stringify(allowedSources));
    form.set('photo', photo.files[0]);
    await apiForm('/api/faces', form);
  }, 'Perfil facial cadastrado') }, 'Cadastrar pessoa autorizada');

  const cards = rows.map(profile => {
    const refPhoto = h('input', { type: 'file', accept: 'image/*' });
    const same = h('input', { type: 'checkbox' });
    const add = profile.active ? h('div', {}, refPhoto,
      h('label', { class: 'ck' }, same, 'Confirmo que esta imagem mostra a mesma pessoa autorizada'),
      h('button', { class: 'b sec', onclick: () => act(async () => {
        if (!refPhoto.files || !refPhoto.files[0]) throw new Error('Selecione a foto adicional.');
        const form = new FormData(); form.set('photo', refPhoto.files[0]);
        form.set('same_person_confirmed', same.checked ? 'true' : 'false');
        await apiForm(`/api/faces/${profile.id}/references`, form);
      }, 'Referência adicionada') }, 'Adicionar outra referência')) : null;
    const revoke = profile.active ? h('button', { class: 'b bad', onclick: () => confirm('Revogar a autorização, apagar as referências biométricas e limpar as marcações faciais dos clipes? Os vídeos existentes não serão apagados.') && act(() => api(`/api/faces/${profile.id}`, { method: 'DELETE' }), 'Consentimento revogado; biometria e marcações faciais removidas') }, 'Revogar autorização') : null;
    return h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, profile.name), pill(profile.active ? 'autorização ativa' : 'inativo / revogado', profile.active ? 'ok' : 'warn')),
      h('p', { class: 'muted' }, 'Finalidade: ' + (profile.consent_scope || '—')),
      h('p', { class: 'muted' }, 'Registro da autorização: ' + (profile.consent_evidence || '—')),
      h('p', { class: 'muted' }, 'Fontes autorizadas: ' + ((profile.consent_sources || []).map(id => sourceNames.get(Number(id)) || `fonte #${id}`).join(', ') || 'nenhuma')),
      h('p', { class: 'muted' }, `Referências: ${profile.reference_count || 0} · validade: ${fmtT(profile.consent_expires)}`),
      add, revoke);
  });

  return [h('div', { class: 'card' }, h('h3', {}, 'Pessoas autorizadas'),
    h('p', { class: 'muted' }, 'O reconhecimento é aplicado somente às fontes selecionadas e autorizadas. A foto enviada gera uma referência biométrica cifrada; a imagem original não é guardada pelo módulo.'),
    name, scope, evidence, h('label', {}, 'Fontes explicitamente autorizadas'), ...(sourceInputs.length ? sourceInputs : [h('p', { class: 'err' }, 'Cadastre uma fonte antes de criar um perfil facial.')]),
    h('label', {}, 'Validade da autorização (opcional)'), expires, photo,
    h('label', { class: 'ck' }, consent, 'Confirmo que existe autorização expressa para usar a biometria nesta finalidade e nas fontes marcadas.'), create),
    ...(cards.length ? cards : [h('div', { class: 'card muted' }, 'Nenhuma pessoa cadastrada.')])];
}

'''


def repair_frontend(source: str) -> str:
    tabs_old = "const TABS = [['painel', '📊', 'Painel'], ['fontes', '🔌', 'Fontes'], ['clipes', '🎬', 'Clipes'], ['pubs', '🚀', 'Posts'], ['falhas', '⚠️', 'Falhas'], ['config', '⚙️', 'Config'], ['logs', '📜', 'Logs']];"
    tabs_new = tabs_old[:-2] + ", ['rostos', '👤', 'Rostos']];"
    if source.count(tabs_old) != 1:
        fail("app.js: não encontrei exatamente a lista de abas esperada")
    source = source.replace(tabs_old, tabs_new)
    mapping_old = "logs: vLogs }[tab])"
    mapping_new = "logs: vLogs, rostos: vRostos }[tab])"
    if source.count(mapping_old) != 1:
        fail("app.js: não encontrei exatamente o mapa de renderização")
    source = source.replace(mapping_old, mapping_new)
    marker = "if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});"
    if source.count(marker) != 1:
        fail("app.js: não encontrei o marcador final para inserir a tela Rostos")
    if "async function vRostos()" in source:
        fail("app.js: a tela Rostos já existe; recusando duplicar")
    if "async function apiForm(" not in source:
        api_marker = "const fmtT = t =>"
        if source.count(api_marker) != 1:
            fail("app.js: não encontrei o marcador para inserir o helper multipart")
        source = source.replace(api_marker, API_FORM_HELPER + "\n" + api_marker)
    source = source.replace(marker, FACES_UI + marker)
    return source


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd(), help="raiz do clone local")
    parser.add_argument("--branch", default=BRANCH_DEFAULT)
    parser.add_argument("--push", action="store_true", help="após testes verdes, criar commit e enviar somente para a branch informada")
    parser.add_argument("--skip-tests", action="store_true", help="não recomendado; apenas compila e aplica alterações")
    args = parser.parse_args()
    if args.push and args.skip_tests:
        fail("--push não pode ser combinado com --skip-tests; commit/push bloqueados", 2)

    repo = args.repo.resolve()
    try:
        root = run(["git", "rev-parse", "--show-toplevel"], repo).stdout.strip()
    except Exception:
        fail("execute dentro de um clone Git do Xhakinha")
    if Path(root).resolve() != repo:
        fail(f"--repo precisa ser a raiz Git: {root}")
    branch = run(["git", "branch", "--show-current"], repo).stdout.strip()
    if branch != args.branch:
        fail(f"branch atual é {branch!r}; esperado {args.branch!r}. Não vou trocar de branch automaticamente")
    dirty_lines = run(
        ["git", "status", "--porcelain", "--untracked-files=all"], repo
    ).stdout.splitlines()
    # O pacote de reparo precisa ser enviado ao Codespaces para execução. Seus
    # próprios arquivos auxiliares não são código do produto e não devem fazer
    # a verificação de árvore limpa abortar. Qualquer outra alteração continua
    # bloqueando a execução.
    allowed_tool_files = {
        "repair_xhakinha.py",
        "README_Xhakinha_Reparo.md",
        "MANUAL_KAGGLE_CHECKLIST.md",
        "RELATORIO_AUDITORIA.md",
        "Xhakinha_Reparo_Branch_VALIDADO.zip",
    }
    unexpected = []
    for item in dirty_lines:
        status, path_text = item[:2], item[3:].strip()
        path_text = path_text.strip('"')
        is_tool = (
            status == "??"
            and (
                path_text in allowed_tool_files
                or path_text.startswith("xhakinha-repair-kit/")
            )
        )
        if not is_tool:
            unexpected.append(item)
    if unexpected:
        fail(
            "a árvore Git tem alterações locais que não pertencem ao pacote de reparo. "
            "Faça backup/commit/stash manualmente antes; nada foi alterado.\n"
            + "\n".join(unexpected)
        )

    for key, path in FILES.items():
        if key == "face_tests":
            if (repo / path).exists():
                fail(f"teste destino já existe: {path}; revise manualmente antes")
            continue
        if not (repo / path).is_file():
            fail(f"arquivo esperado não encontrado: {path}")

    originals = {
        key: (repo / path).read_text(encoding="utf-8")
        for key, path in FILES.items() if key != "face_tests"
    }
    updated = {
        "db": repair_db(originals["db"]),
        "faces": repair_faces(originals["faces"]),
        "faces_web": repair_faces_web(originals["faces_web"]),
        "pipeline": repair_pipeline_faces(repair_pipeline(originals["pipeline"])),
        "app": repair_app(originals["app"]),
        "frontend": repair_frontend(originals["frontend"]),
        "turso_tests": repair_turso_tests(originals["turso_tests"]),
        "face_tests": FACE_TESTS,
    }
    for key, content in updated.items():
        if FILES[key].suffix == ".py":
            try:
                compile(content, str(FILES[key]), "exec")
            except SyntaxError as exc:
                fail(
                    f"validação prévia de sintaxe falhou em {FILES[key]}: {exc}. "
                    "Nenhum arquivo foi alterado."
                )
    backup_root = Path.home() / "xhakinha-repair-backups" / dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup_root.mkdir(parents=True, exist_ok=False)
    for key, path in FILES.items():
        if key == "face_tests":
            continue
        target = backup_root / (key + "-" + path.name)
        target.write_text(originals[key], encoding="utf-8")
        (repo / path).write_text(updated[key], encoding="utf-8")
    (repo / FILES["face_tests"]).write_text(updated["face_tests"], encoding="utf-8")
    print(f"Backup salvo em: {backup_root}")
    print("Arquivos atualizados:")
    for path in FILES.values(): print(" -", path)

    project = repo / "xhakinha-clips-ai"
    try:
        if not args.skip_tests:
            try:
                run([sys.executable, "-m", "compileall", "-q", "xhakinha"], project)
                print("Python compileall: OK")
            except subprocess.CalledProcessError as exc:
                print(exc.stdout, exc.stderr, file=sys.stderr)
                fail("compileall falhou; arquivos restaurados, sem commit/push", 1)

            # Valida JSON, AST de cada célula e o gate remoto D1 do notebook oficial.
            # Essa função é somente estática: não consulta serviços nem chama main().
            try:
                payload = run(
                    [
                        sys.executable,
                        "-c",
                        "from scripts.kaggle_trigger import validate_kaggle_payload; "
                        "print(validate_kaggle_payload())",
                    ],
                    project,
                )
                print(payload.stdout.strip())
                print("Kaggle payload / AST / gate D1: OK")
            except subprocess.CalledProcessError as exc:
                print(exc.stdout, exc.stderr, file=sys.stderr)
                fail("validação estática do notebook Kaggle falhou; arquivos restaurados, sem commit/push", 1)

            node = shutil.which("node")
            if not node:
                fail("Node.js não está instalado; não vou declarar a suíte completa sem o teste Cloudflare", 1)
            try:
                run([node, "--check", str(FILES["frontend"])], repo)
                print("JavaScript node --check: OK")
                cloudflare = project / "cloudflare"
                node_tests = run(
                    [node, "--experimental-sqlite", "--test", "test/core.test.mjs"],
                    cloudflare,
                    check=False,
                )
                print(node_tests.stdout)
                if node_tests.returncode:
                    print(node_tests.stderr, file=sys.stderr)
                    fail("testes Cloudflare/Node falharam; sem commit/push", 1)
                print("Cloudflare Node tests: OK")
            except subprocess.CalledProcessError as exc:
                print(exc.stdout, exc.stderr, file=sys.stderr)
                fail("validação JavaScript/Cloudflare falhou; arquivos restaurados, sem commit/push", 1)

            try:
                test = run([sys.executable, "-m", "pytest", "-q"], project, check=False)
                print(test.stdout)
                if test.returncode:
                    print(test.stderr, file=sys.stderr)
                    fail("pytest falhou; arquivos restaurados, sem commit/push", 1)
            except FileNotFoundError:
                fail("pytest não está instalado no ambiente local; sem commit/push", 1)

    except SystemExit:
        for key, path in FILES.items():
            target = repo / path
            if key == "face_tests":
                target.unlink(missing_ok=True)
            elif key in originals:
                target.write_text(originals[key], encoding="utf-8")
        print("Validação falhou: restaurei os arquivos de produto ao estado anterior. "
              f"O backup permanece em {backup_root}.", file=sys.stderr)
        raise

    if args.push:
        try:
            run(["git", "diff", "--check"], repo)
            print("git diff --check: OK")
            run(["git", "add", *(str(p) for p in FILES.values())], repo)
            run(["git", "commit", "-m", "fix: restore web pipeline and add face profiles UI"], repo)
            run(["git", "push", "origin", args.branch], repo)
            print(f"Commit enviado para origin/{args.branch}")
            print("O Render permanece intocado; ele está configurado em outra branch.")
        except subprocess.CalledProcessError as exc:
            print(exc.stdout, exc.stderr, file=sys.stderr)
            fail("falha no commit/push; as alterações locais e o backup permanecem disponíveis", 1)
    else:
        print("Sem commit/push. Use --push somente depois de revisar os testes e o diff.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
