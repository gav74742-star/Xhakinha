# Checklist manual de implantação — Xhakinha Clips AI / Kaggle

Este roteiro usa a versão que já está em `feature/production-hardening-20261127` e o notebook operacional único `xhakinha-clips-ai/kaggle/kaggle_worker.ipynb`.

## 1. Primeiro concluir o código no GitHub

1. No Codespaces, execute o `repair_xhakinha.py` conforme o README do pacote.
2. O script só deve fazer commit/push se passarem todos os testes: Python, validador do notebook Kaggle, JavaScript, testes Node do Cloudflare e `pytest`.
3. No GitHub, abra um Pull Request de `feature/production-hardening-20261127` para `main`.
4. Só faça merge quando o workflow `tests` estiver **verde**. Se falhar, não faça merge; leia o primeiro erro real dos logs.
5. O notebook está com `BRANCH = "main"`. Isso é intencional: só depois do merge ele deve puxar a versão consolidada.

## 2. Segredos do Kaggle

Abra o notebook existente `GAv7489/xhakinha-worker` na sua conta Kaggle e entre em **Add-ons → Secrets**. Cadastre/associe estes nomes exatamente, sem colocar valores no código:

```text
SECRET_KEY
XH_COORD_URL
XH_COORD_TOKEN
TURSO_DATABASE_URL
TURSO_AUTH_TOKEN
B2_ENDPOINT_URL
B2_REGION
B2_KEY_ID
B2_APPLICATION_KEY
B2_BUCKET
```

Cuidados importantes:

- `SECRET_KEY` precisa ser o mesmo segredo que a aplicação Xhakinha usa para descriptografar os tokens que já estão guardados no banco. Não gere outro valor nem faça rotação nesta etapa.
- `XH_COORD_URL` e `XH_COORD_TOKEN` precisam apontar para o coordenador Cloudflare D1 correto. `XH_COORD_TOKEN` é o token do notebook/coordenador, não confunda com `XH_ADMIN_TOKEN` do GitHub Actions.
- `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN` devem pertencer ao banco Turso que contém o estado canônico do Xhakinha.
- `B2_ENDPOINT_URL`, `B2_REGION`, `B2_KEY_ID`, `B2_APPLICATION_KEY` e `B2_BUCKET` precisam ser do mesmo bucket privado de produção/snapshots. Não use credenciais de outro bucket.
- Nunca cole nenhum desses valores no chat, no README, no notebook ou em logs públicos.

## 3. Segredos separados do GitHub Actions

No repositório GitHub, em **Settings → Secrets and variables → Actions**, confira estes quatro segredos usados pelo workflow `kaggle-trigger`:

```text
XH_COORD_URL
XH_ADMIN_TOKEN
KAGGLE_USERNAME
KAGGLE_KEY
```

`XH_ADMIN_TOKEN` é para a ação do GitHub consultar/controlar o coordenador; não é o mesmo nome do `XH_COORD_TOKEN` que o notebook lê nos Kaggle Secrets.

## 4. Configuração do notebook Kaggle

No notebook existente, abra as opções de sessão:

- Internet: habilitada.
- Accelerator: GPU habilitada quando disponível na sua cota da conta.
- Notebook privado, conforme o `kernel-metadata.json` do repositório.
- Não crie um segundo notebook/Worker. O identificador oficial é `GAv7489/xhakinha-worker`.

Depois que `main` estiver atualizado, sincronize somente o arquivo `xhakinha-clips-ai/kaggle/kaggle_worker.ipynb` com o notebook existente. Há duas formas:

**Pela interface Kaggle:** no editor do notebook, use **File → Link to GitHub**, autorize o GitHub, escolha `gav74742-star/Xhakinha` e vincule o arquivo `xhakinha-clips-ai/kaggle/kaggle_worker.ipynb`. Confira que está atualizando o kernel existente, não criando outro.

**Pela CLI Kaggle no Codespaces:** depois de autenticar a CLI na sua conta Kaggle e configurar `KAGGLE_USERNAME`/`KAGGLE_KEY` como segredos do ambiente, rode a partir da raiz do repositório:

```bash
kaggle kernels push -p xhakinha-clips-ai/kaggle --no-run
```

`--no-run` salva uma nova versão do notebook sem executar suas células. Não rode `kaggle kernels push` sem `--no-run` nesta etapa: sem essa opção, o Kaggle envia e inicia a execução do notebook.

## 5. Execução controlada — na ordem

A versão atual do repositório tem **40 células físicas, das quais 19 são células de código**. A numeração operacional é somente a das células de código; não use a posição física/índice do editor.

Depois de sincronizar a versão, abra o notebook existente e execute as células de código em sequência, uma de cada vez. Leia cada resultado antes de avançar:

- **Código 1 a 15:** preparação, secrets (somente presença), healthcheck, imports, Turso, coordenador, B2, locks/executores, cópia isolada, dry-run, idempotência, relatório, estado e pré-validação.
- **Código 16 — 15B:** bootstrap de snapshot. Pode criar o primeiro snapshot (uma gravação no B2) e usa lock temporário no coordenador. Só execute depois dos diagnósticos anteriores aprovados.
- **Código 17 — 15C:** conferência remota final; leitura/validação.
- **Código 18 — 15D:** gate final e testes offline; não inicia publicação.
- **Código 19 — inicialização real:** deixe bloqueada até existir autorização expressa para iniciar o Worker. Ela consulta o coordenador; só permite `main()` quando `launch_enabled=true` e todos os gates anteriores estão aprovados.

Uma tabela `sources` consultável e vazia não é, por si só, falha técnica. Cadastre fontes depois pelo painel, com autorização e escopo corretos.

## 6. O que NÃO ativar durante o diagnóstico

- Não altere o último código para forçar `main()`.
- Não altere manualmente `launch_enabled` para `true` enquanto estiver só testando.
- Não dispare o workflow `kaggle-trigger` manualmente durante o diagnóstico.
- Não rode `kaggle kernels push` sem `--no-run` para apenas sincronizar o código.
- Não habilite plataformas nem cadastre fontes sem autorização e sem revisar a fila existente.

O workflow `kaggle-trigger` está agendado para verificar o coordenador a cada 30 minutos. Ele só faz `kaggle kernels push` quando o coordenador autoriza lançamento e existe tarefa GPU elegível. Quando isso acontecer, já não será apenas uma sincronização: será o início de uma execução real.

## 7. Como reconhecer que a etapa foi concluída

Antes de autorizar o Worker, todos estes itens precisam estar verdadeiros:

- PR incorporado em `main` depois de CI verde.
- Notebook existente sincronizado com a versão de `main` (salvo sem executar, caso use `--no-run`).
- Os dez Kaggle Secrets aparecem como disponíveis, sem mostrar seus valores.
- As células de diagnóstico aprovam leitura do Turso, coordenador e B2.
- O snapshot de bootstrap foi validado/criado conscientemente.
- 15C e 15D passam; relatório final sem bloqueios críticos.
- A fila, as fontes e as contas de publicação foram revisadas.
- Só então, mediante autorização explícita, o coordenador pode liberar `launch_enabled` para iniciar o Worker.

## 8. Verificação estática segura no Codespaces

Este comando apenas valida o arquivo local e o gate do notebook; não acessa Turso, B2, Cloudflare nem Kaggle, e não inicia `main()`:

```bash
cd xhakinha-clips-ai
python -c "from scripts.kaggle_trigger import validate_kaggle_payload; print(validate_kaggle_payload())"
```

O pacote de reparo já executa esse validador automaticamente antes do commit/push.
