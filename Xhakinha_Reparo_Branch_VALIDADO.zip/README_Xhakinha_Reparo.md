# Xhakinha Clips AI — pacote de reparo e validação

Este pacote corrige a branch `feature/production-hardening-20261127`. Ele **não cria um segundo Worker e não substitui o notebook Kaggle operacional** já existente no repositório.

## O que será corrigido

- Corrige a indentação de `xhakinha/pipeline.py` e `xhakinha/web/app.py`, que está impedindo a coleta de testes no CI atual.
- Adiciona a aba **Rostos** ao painel, ligada às rotas biométricas já existentes.
- Cada perfil facial fica limitado aos IDs de fontes selecionadas no cadastro e que continuam com `authorized=1`. Sem fonte explícita ou fonte autorizada, o reconhecimento falha fechado.
- Migra o esquema para a versão 6 com `consent_sources`, preservando a migração de bancos já existentes.
- Na revogação, apaga as referências biométricas cifradas e remove somente as marcações daquele perfil dos metadados dos clipes. Os vídeos não são apagados; marcações de outros perfis válidos são preservadas. JSON de marcação inválido é limpo por segurança.
- Inclui testes de escopo por fonte, fonte não autorizada, expiração, revogação, normalização, cifra, limite de referências e limpeza das marcações faciais.
- Executa também o validador estático do notebook existente (JSON, AST de todas as células e gate remoto D1), o `node --check`, os testes Node do Cloudflare e a suíte `pytest`.

## Como usar no GitHub Codespaces pelo celular

1. No terminal do Codespaces, confirme que está na raiz `/workspaces/Xhakinha` e na branch correta:

   ```bash
   pwd && git status --short --branch
   ```

   A branch precisa ser `feature/production-hardening-20261127`. O script não troca de branch automaticamente.

2. No Explorer do Codespaces, toque com o botão direito na pasta raiz `Xhakinha` e escolha **Upload**. Envie `Xhakinha_Reparo_Branch_VALIDADO.zip`. Depois, no terminal, extraia os quatro arquivos na raiz:

   ```bash
   unzip -o Xhakinha_Reparo_Branch_VALIDADO.zip -d .
   ```

   O ZIP contém `repair_xhakinha.py`, `README_Xhakinha_Reparo.md`, `MANUAL_KAGGLE_CHECKLIST.md` e `RELATORIO_AUDITORIA.md`. O script ignora somente esses arquivos auxiliares do pacote na checagem de árvore limpa. Qualquer outra alteração local bloqueia a execução.

3. Instale as dependências usadas pela CI (não cole segredos nesse terminal):

   ```bash
   sudo apt-get update && sudo apt-get install -y ffmpeg
   python -m pip install -r xhakinha-clips-ai/requirements.txt -r xhakinha-clips-ai/requirements-dev.txt
   ```

4. Para aplicar, testar tudo e enviar commit **somente para a branch de desenvolvimento**, execute:

   ```bash
   python repair_xhakinha.py --push
   ```

   O script cria backup em `~/xhakinha-repair-backups/`, valida em memória a sintaxe Python antes de escrever e então roda:
   - `compileall` do pacote Python;
   - `scripts.kaggle_trigger.validate_kaggle_payload()` (validação local, sem rede, sem `main()` e sem disparar Kaggle);
   - `node --check` do painel;
   - `node --experimental-sqlite --test test/core.test.mjs` do Cloudflare;
   - `python -m pytest -q`.

   Só depois de tudo passar ele executa `git diff --check`, cria o commit e tenta `git push` para `origin/feature/production-hardening-20261127`. Não faz merge, deploy, execução Kaggle ou publicação de vídeos.

5. Se houver falha em qualquer gate de validação, o script **não** faz commit nem push e restaura automaticamente os arquivos de produto ao estado anterior. O backup original permanece em `~/xhakinha-repair-backups/`. Envie a mensagem de erro/captura para revisão antes de tentar novamente.

## Depois do push

Abra um Pull Request de `feature/production-hardening-20261127` para `main`. Aguarde o workflow `tests` terminar verde. Só então faça merge. Não mude o notebook para puxar a branch de feature: o notebook oficial está preparado para seguir `main` depois do merge.

## Segurança

- Não cole `SECRET_KEY`, `XH_COORD_TOKEN`, tokens Turso, chaves B2, senhas ou chaves Kaggle no chat, no código ou em mensagens de log.
- O pacote não contém credenciais.
- O notebook atual do repositório já é o único Worker operacional: `xhakinha-clips-ai/kaggle/kaggle_worker.ipynb`. Não envie os arquivos antigos `kaggle_worker_operacional_corrigido.ipynb` ou `kaggle_worker_turso_b2_corrigido_r3.ipynb` por cima dele: as cópias da Biblioteca são anteriores ao gate remoto D1 da branch atual.
- O código final do notebook só chama `main()` quando o coordenador remoto confirma `launch_enabled=true` e todos os gates 15B/15C/15D e pré-validações passam. Mantenha essa autorização desativada durante testes.
- A etapa 15B (célula de código 16) pode gravar o primeiro snapshot no B2 e usa um lock temporário no coordenador. Execute somente após todos os diagnósticos anteriores passarem.
- A última célula (célula de código 19) é inicialização real, não diagnóstico. Não a libere nem ative `launch_enabled` até ter autorização explícita para iniciar o Worker e revisar a fila/contas de publicação.

## O que ainda exige validação externa

O script e os testes no Codespaces podem provar sintaxe, lógica local, estrutura do notebook e regressões cobertas. Eles não provam, sem executar com os Secrets reais, que sua conta Kaggle consegue acessar Turso, B2, Cloudflare D1, quota de GPU ou OAuth de TikTok/Instagram. Essa confirmação é feita na execução controlada do notebook, depois da CI verde.
